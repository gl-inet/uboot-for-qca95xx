1. Find a openwrt tree
2. Put all the code as package/uboot/qca-legacy-uboot-nand
3. make menuconfig
4. choose qca-legacy-uboot-cus531-nand
5. make package/qca-legacy-uboot-nand/compile V=s
6. find the uboot bin in bin/ar71xx/openwrt-ar71xx-cus531-nand-qca-legacy-uboot.bin
