/************************************************
 * NAME                 arm946es.h              *
 * $Version$                                    *
 ************************************************/
/* Currently empty */
#ifndef __ARM946ES_H__
#define __ARM946ES_H__
#endif /*__ARM946ES_H__*/
