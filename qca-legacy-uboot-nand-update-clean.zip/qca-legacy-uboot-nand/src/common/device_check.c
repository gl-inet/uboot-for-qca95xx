#include <common.h>
#include <watchdog.h>
#include <command.h>
#ifdef CONFIG_MODEM_SUPPORT
#include <malloc.h>		/* for free() prototype */
#endif

#ifdef CFG_HUSH_PARSER
#include <hush.h>
#endif

#include <post.h>

/* for isdigit() */
#include <linux/ctype.h>
#include <asm-mips/string.h>

#define  __DEBUG__
#ifdef __DEBUG__
#define DEBUG(formt,...) printf(formt,##__VA_ARGS__)
#else
#define DEBUG(formt,...)
#endif

extern char nand_boot_failed;
extern char tftp_file;
extern int do_nand(cmd_tbl_t * cmdtp, int flag, int argc, char *argv[]);
int check_nand()
{
	int argc=2;
	char *argv[2];
	argv[0] = "2";
	argv[1] = "bad";
	return !do_nand(NULL,0,argc,argv);
}

extern int do_ping (cmd_tbl_t *cmdtp, int flag, int argc, char *argv[]);

int select_boot_dev(){
	char *dev=NULL;
	unsigned int val=0;

	dev = getenv("boot_dev");
	if(strcmp(dev,"on") == 0)
	{
		val = switch_boot_load();
		//printf("val is %d\n",val);
		switch(val)//from nand boot
		{
		case 1: run_command("nboot 0x81000000 0",0);break;
		case 2: run_command("bootm 0x9f050000",0);break;
		default: break;
		}
	}
}


